						ROBO

What is it? 
-----------
  
Robo is a remote-display tool. It is not the first system providing such 
functionality, but I believe it is the first one written entirely in Java.
It should run on any computer platform that supports Java.

Screen capture, mouse and keyboard control functionality became available in 
Java since version 1.3 via java.awt.Robot class. Thus, the name - Robo.
  

Why?
----

Just for the fun of it.  


Documentation
-------------

Documentation is available in HTML format, in the docs/ directory.


Licensing
---------

This software is licensed under GNU GPL.
  

Good luck,

Boris Galinsky
sanych@comcast.net
